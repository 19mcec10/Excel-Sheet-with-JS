/* Name= Karan patel;
Course: INFO6122 (Programming JavaScript)
Professor: Sumit Shrestha
File:HTMl+CSS file
Project: DOM Manipulation(Addition)   */      
 
let buttonClear = document.getElementById('clr'); //store clear button in variable  

var bodyobject = document.body;  //store body in variable
 // creation of dynamic table
function creteTable(){       
var table = document.createElement('table');    // store table element in variable
table.setAttribute("border","2px");    //applying style to table
var tableBody = document.createElement('tbody');     //creation of table body
table.appendChild(tableBody);    //holding of table body object in table variable
bodyobject.appendChild(table);  //appending table into body

var alfabat=65;     //to assign alphabet to raw 
const q = [];        //array to contain generated alphabets
// this two for loop  is used to assign ID to cells
for (var i=0; i<=10; i++)
{

    var tr = document.createElement('tr');   //assigned row to this loop
    tableBody.appendChild(tr);
    tr.appendChild(document.createTextNode(i));
    for (var j=0; j<10; j++){              //assigned colomn to this loop
        var td = document.createElement('td');
      
        
        tr.appendChild(td);
        
            if(i==0){        //only assign alphabets to first row cells

                //fromCharCode is use to convert ascii value to char        
            td.appendChild(document.createTextNode(String.fromCharCode(alfabat)));
            td.setAttribute("width",75);
            alfabat++;
            q[j]=  td.innerHTML;
                    }
        if(i>0)
        {
          // q will describe alphabets [A-J] and i will describe number and together both  form  a string         
        td.id=q[j]+i;  //Id is assigned to each cell so can use in calculation of two cells
      
    }
    }
}
// Calculation portion starts from here

table.id = 'My_table';    //assigned Id to table
var t = document.getElementById('My_table');   //assigned table to variable t
var trs = t.getElementsByTagName('tr');     //assigned rows to trs variable
var tds = null;
var msgbtn = document.getElementById("name");   //textbox has been assigned with varible
//keep disable textbox if there isn't any use so that user can not enter value without selection cell
msgbtn.setAttribute("disabled",true);    
var x;   //variable x is used to hold cell which user has selected

//two for loops are used to implement logic of event for selection of cell
 for (var i=1; i<trs.length; i++)
 {
     tds = trs[i].getElementsByTagName("td");
     for (var n=0; n<tds.length;n++)
     {
        
               
         tds[n].addEventListener("click",onclick);    //added onclick event to select  cell
         
         
         function onclick(event){     
          
            x = event.target; //x will hold the selected object 
      //1> focus the text box 
      //2>open the text box to inert value 
      //3>set color to cell 
            msgbtn.removeAttribute("disabled");       
            msgbtn.focus();
                         
            x.setAttribute("class","backg");
            
                                  }
        }

 }

//adding event on clear button

 buttonClear.addEventListener("click",clear);
 function clear()
{

  for (var i=1; i<trs.length; i++)
  {
      tds = trs[i].getElementsByTagName("td");
      for (var n=0; n<tds.length;n++)
      {
       if(i>0) 
             {   
            //1> remove focus from text-box
            //2> remove styling on cells
            //3> set empty to all cells   
            msgbtn.blur();
            tds[n].removeAttribute("class","backg");
            tds[n].innerHTML="";
          
           
        }

      }

  }

 }

 //adding an event on textbox
 msgbtn.addEventListener("keypress",script);
        
  function script(event)
  {
          
          const regx = /(=[A-J]([1-9]|10)\+[A-J]([1-9]|10))/ig;   //"=cellID + cellID" allow this pattern only      
         //Three conditions are placed here
         //1>will check  pressed key is number and inserted value is number then only
         //it will allow
          
         if(event.keyCode === 13 && !(isNaN(msgbtn.value)))
                     
         {
                
                     
          x.removeAttribute("class","backg");  //remove backgroung color
          var valueHolder;  //variable hold the inserted value
          valueHolder=msgbtn.value;  
          x.innerHTML = valueHolder;  //place that value in selected cell
          msgbtn.value="";     //make empty textbox
          msgbtn.blur();      //remove focus
          msgbtn.setAttribute("disabled",true);   //make disable till next cell selection event
         }
         
         //2> if inserted string is for addition of two  cells then only allows
         // check that expression with expression cheacker variable
         else if(event.keyCode === 13 && (regx.test(msgbtn.value)))
         {
          
          var expression=msgbtn.value.toUpperCase();
          //1>split expression from '+' sign
          //2>split expression from '=' sign
          //3>collect the Ids from two array
          //4>get the value through id by converting them into integer
          //5>add two values
          var e1=expression.split("+");   
          var e2=e1[0].split("=");
          console.log(e1[1]+" "+e2[1]);
          var z1 = parseInt(document.getElementById(e2[1]).innerHTML);
          var z2 = parseInt(document.getElementById(e1[1]).innerHTML);

          var z3=z1+z2;
          //set filter for those selected cells on which value is not assigned
                               
                          if(!(isNaN(z3)))  //if sum is number
                          {   //1>assign sum to selected row
                              //2>remove color
                              //3>set text box empty
                              //4>remove focus from textbox
                              //5>disable text box
                               x.innerHTML = z3;
                               x.removeAttribute("class","backg");
                              msgbtn.value="";
                              msgbtn.blur();
                              msgbtn.setAttribute("disabled",true);
                          }
                          
                          else{    //sum is  not  number then user has entered cell number on which
                                   //values are not assigned
                              msgbtn.value="";
                              x.removeAttribute("class","backg");
                              msgbtn.blur();     
                              window.alert("set values on cell before applying sum");
                              }
          
      

            }

        //3>this control structure will handle if user has not entered appropriate number
        // or expression
         
         else if(event.keyCode === 13  && (isNaN(msgbtn.value)))  
         {
         
          window.alert("Enter Number Or Appropriate expression");
          msgbtn.value="";
          msgbtn.blur();
          x.removeAttribute("class","backg");

         }
         
     }
 

}